import{InjectionToken as e}from"@angular/core";var t=new e("REMOTE_WIDGET_LOADER");export{t as a};
